function [yn,t] = motorNoiseModel_pre(f0,hc,As,An)

% MOTORNOISEMODEL_PRE Models an electric motor sound signal (preallocation)
%
% Uses a model of the form
% y = As*y0 + An*noise
% where y0 is a sum of n harmonics
% yn = sin(2*pi*n*f0*t)
% and noise is random noise added to the motor sound signal
%
% [y,t] = motorNoiseModel_fun(f0,coeffs,As,An)
% Inputs:
% f0      Fundamental frequency
% coeffs  Vector of coefficients of the harmonics
% As      Amplitude of the signal
% An      Amplitude of the noise
%
% Outputs:
%  y       The sound signal
%  t       Time base for the sound signal

% Create the time base for the signal.
fs = 44100;
t = 0:1/fs:0.8;

% Create the harmonics.
y0 = zeros(size(t));
for k = 1:length(hc)
    y0 = y0 + hc(k)*sin(2*pi*k*f0*t);
end

% Create the motor sound model.
y = As*y0;

% Add noise.
yn = zeros(size(y));
for k = 1:length(y)
    n = An*randn;
    yn(k) = y(k) + n;
end
