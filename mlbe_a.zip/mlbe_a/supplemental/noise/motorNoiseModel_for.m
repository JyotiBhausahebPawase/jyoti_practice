% MOTORNOISEMODEL Models an electric motor sound signal.
%
% Uses a model of the form
% y = As*y0 + An*noise
% where y0 is a sum of n harmonics
% yn = sin(2*pi*n*f0*t)
% and noise is random noise added to the motor sound signal

% Create the time base for the signal.
fs = 44100;
t = 0:1/fs:0.8;

% Set the fundamental frequency.
f0 = 415;
% Set the coefficients of the harmonics.
hc = [0.33,0,0.23,0,0,1];

% Create the harmonics.
y0 = zeros(size(t));
for k = 1:length(hc)
    y0 = y0 + hc(k)*sin(2*pi*k*f0*t);
end

% Create the noise.
noise = 0.023 + 0.05*randn(size(y0));
       
% Create the motor sound model.
y = 0.122*y0 + noise;

% Plot the noise model and listen to it.
figure
plot(t,y)
axis([0 t(end) -0.3 0.3])
xlabel('Time')
ylabel('Amplitude')
title('{\bf Electric Motor Noise Model}')
sound(y,fs)
