% MOTORNOISEMODEL Models an electric motor sound signal.
%
% Uses a model of the form
% y = As*y0 + An*noise
% where y0 is a sum of n harmonics
% yn = sin(2*pi*n*f0*t)
% and noise is random noise added to the motor sound signal

% Create the time base for the signal.
fs = 44100;
t = 0:1/fs:0.8;

% Set the fundamental frequency.
f0 = 415;

% Create the harmonics.
y1 = sin(2*pi*f0*t);
y2 = sin(2*pi*3*f0*t);
y3 = sin(2*pi*6*f0*t);
y0 = 0.33*y1 + 0.23*y2 + y3;

% Create the noise.
noise = 0.023 + 0.05*randn(size(y0));
       
% Create the motor sound model.
y = 0.122*y0 + noise;

% Plot the noise model and listen to it.
figure
plot(t,y)
axis([0 t(end) -0.3 0.3])
xlabel('Time')
ylabel('Amplitude')
title('{\bf Electric Motor Noise Model}')
sound(y,fs)
