%% NOISEWRITE Demonstrates the use of AUWRITE for exporting audio data.
%
% See also: MOTORNOISEMODEL.M

%% Run motorNoiseModel
motorNoiseModel
y = y/max(y);

%% Write the motor noise signal to the file noisemodel.au in the 
% C:\CLASS\WORK directory using 8-bit mu-law encoding. 
% The directory must exist before you can write to it.
auwrite(y,fs,8,'mu','C:\class\work\noisemodel.au')

%% Open the default Windows media player and listen to the file.
winopen('C:\class\work\noisemodel.au')