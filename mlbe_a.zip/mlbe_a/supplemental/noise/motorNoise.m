%% MOTOR_NOISE Signal analysis of an electric fan motor
% Noise in a vehicle can cause dissatisfaction for a great number of customers.
% It is important to understand the noise sources and its characteristics to be 
% able to reduce it to an acceptable level.
% motor_noise.m analyzes the noise of an electric fan motor.

%% Read in the data and listen to it.
[y,fs] = wavread('motor.wav');
sound(y,fs)

%% Visualize the signal.
t = (0:1/fs:(length(y)-1)/fs)'; % Time base.
figure
plot(t,y)
axis([0 t(end) -0.3 0.3])
xlabel('Time')
ylabel('Amplitude')
title('{\bf Electric Motor Nose signal}')

%% Index into the signal to better see a section
section= y(t>=2.0 & t<=2.8);
tsec = (0:1/fs:(length(section)-1)/fs)'; % Time base.
figure
plot(tsec,section)
axis([0 tsec(end) -0.3 0.3])
xlabel('Time')
ylabel('Amplitude')
title('{\bf Section of Electric Motor Noise signal (0.8 secs)}')
hold on
