function model = motorNoiseModel_struct(motor)

% MOTORNOISEMODEL_STRUCT Models an electric motor sound signal.
%
% Uses a model of the form
% y = As*y0 + An*noise
% where y0 is a sum of n harmonics
% yn = sin(2*pi*n*f0*t)
% and noise is random noise added to the motor sound signal
%
% [y,t] = motorNoiseModel_fun(motor)
% Inputs:
% motor   A structure with fields:
%            partnumber
%            fundamentalfreq
%            signalamplitude
%            noiseamplitude
%            harmcoeffs
%
% Outputs:
%  model       The sound signal
%  t       Time base for the sound signal

% Create the time base for the signal.
fs = 44100;
t = 0:1/fs:0.8;

% Create the harmonics.
y0 = zeros(size(t));
for k = 1:length(motor.harmcoeffs)
    y0 = y0 + motor.harmcoeffs(k)*sin(2*pi*k*motor.fundamentalfreq*t);
end

% Create the noise.
noise = 0.023 + motor.noiseamplitude*randn(size(y0));
       
% Create the motor sound model.
y = motor.signalamplitude*y0 + noise;

model.t = t;
model.y = y;
model.partnum = motor.partnumber;

