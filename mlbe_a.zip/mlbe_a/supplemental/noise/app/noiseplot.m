function noiseplot(motor)
figure
plot(motor.t,motor.y)
xlabel('Time')
ylabel('Amplitude')
title(['{\bf Electric Motor Noise Model} -- part number ',motor.partnum])

