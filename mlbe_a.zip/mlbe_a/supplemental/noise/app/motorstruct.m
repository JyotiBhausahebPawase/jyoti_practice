%% MOTORSTRUCT  Creates a structure and passes it to MOTORNOISEMODEL_FUN_S

%% Make a motor structure
motor.partnumber = 'AM62308';
motor.fundamentalfreq = 415;
motor.signalamplitude = 0.122;
motor.noiseamplitude = 0.05;
motor.harmcoeffs = [0.33;0;0.23;0;0;1];

%% Pass the structure to the function
model = motorNoiseModel_struct(motor);

%% Visualize the result
noiseplot(model)
%  Uncomment the following line to hear the sound
%  noiseplay(model)
