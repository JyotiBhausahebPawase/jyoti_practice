%% MOTORSTRUCTARR  Creates a structure array and passes elements to MOTORNOISEMODEL_FUN_S

%% Make a motor structure array
%  Element #1
powerplant(1).partnumber = 'AM62308';
powerplant(1).fundamentalfreq = 415;
powerplant(1).signalamplitude = 0.122;
powerplant(1).noiseamplitude = 0.05;
powerplant(1).harmcoeffs = [0.33;0;0.23;0;0;1];
%  Element #2
powerplant(2).partnumber = 'KG10215';
powerplant(2).fundamentalfreq = 650;
powerplant(2).signalamplitude = 0.2;
powerplant(2).noiseamplitude = 0.1;
powerplant(2).harmcoeffs = [0.5;1;0.5;0;0.2;0.1];
%  Element #3
powerplant(3).partnumber = 'RP13375';
powerplant(3).fundamentalfreq = 372;
powerplant(3).signalamplitude = 0.52;
powerplant(3).noiseamplitude = 0.05;
powerplant(3).harmcoeffs = [0.2;1;0;0.4;0.32;0.46];

%% Choose one motor and pass it to the function
motornum = menu('Choose your motor',{powerplant.partnumber});
%  Extract the chosen motor structure from the array
mymotor = powerplant(motornum);
%  Pass the structure to the function
model = motorNoiseModel_struct(mymotor);

%% Visualize the result
noiseplot(model)
%  Uncomment the following line to hear the sound
%  noiseplay(model)
