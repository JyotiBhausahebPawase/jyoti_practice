function appFunction

data = load('motordata.mat');

motornum = menu('Choose your motor',{data.powerplant.partnumber});

plotorplay = menu('Which post-processing task?','Plot waveform','Play sound');

if plotorplay == 1
    analysisfn = @noiseplot;
else
    analysisfn = @noiseplay;
end

mymotor = data.powerplant(motornum);
motorNoiseModel_fh(mymotor,analysisfn);


function model = motorNoiseModel_fh(motor,postproc)

% MOTORNOISEMODEL_STRUCT Models an electric motor sound signal.
%
% Uses a model of the form
% y = As*y0 + An*noise
% where y0 is a sum of n harmonics
% yn = sin(2*pi*n*f0*t)
% and noise is random noise added to the motor sound signal
%
% [y,t] = motorNoiseModel_fun(motor)
% Inputs:
% motor   A structure with fields:
%            partnumber
%            fundamentalfreq
%            signalamplitude
%            noiseamplitude
%            harmcoeffs
% postproc  A post-processing function to call after the model is computed
%
% Outputs:
%  model       The sound signal
%  t       Time base for the sound signal

% Create the time base for the signal.
fs = 44100;
t = 0:1/fs:0.8;

% Create the harmonics.
y0 = zeros(size(t));
for k = 1:length(motor.harmcoeffs)
    y0 = y0 + motor.harmcoeffs(k)*sin(2*pi*k*motor.fundamentalfreq*t);
end

% Create the noise.
noise = 0.023 + motor.noiseamplitude*randn(size(y0));
       
% Create the motor sound model.
y = motor.signalamplitude*y0 + noise;

model.t = t;
model.y = y;
model.partnum = motor.partnumber;

% Call post-processing function
postproc(model)


function noiseplay(motor)

fs = 1/(motor.t(2)-motor.t(1));
soundsc(motor.y,fs)

function noiseplot(motor)
figure
plot(motor.t,motor.y)
xlabel('Time')
ylabel('Amplitude')
title(['{\bf Electric Motor Noise Model} -- part number ',motor.partnum])

