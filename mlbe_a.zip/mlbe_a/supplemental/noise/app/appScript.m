load('motordata.mat')

motornum = menu('Choose your motor',{powerplant.partnumber});

plotorplay = menu('Which post-processing task?','Plot waveform','Play sound');

if plotorplay == 1
    analysisfn = @noiseplot;
else
    analysisfn = @noiseplay;
end

mymotor = powerplant(motornum);
noisemodel = motorNoiseModel_fh(mymotor,analysisfn);
