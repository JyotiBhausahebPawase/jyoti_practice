function noiseplay(motor)

fs = 1/(motor.t(2)-motor.t(1));
soundsc(motor.y,fs)
