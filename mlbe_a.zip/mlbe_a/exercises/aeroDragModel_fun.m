% Function for "Aerodynamic Drag Model V" exercise
function [V,D] = aeroDragModel_fun(Vlim,vehicle)
Vmph = linspace(Vlim(1),Vlim(2));
V = 0.447*Vmph;
D = calcDrag(V,vehicle);

vname = vehicle.name;
figure
plot(V,D)
xlabel('Velocity [m/s]')
ylabel('Drag force [N]')
title(['Aerodynamic drag for a ',vname,', as a function of velocity'])
end

function D = calcDrag(V,vehicle)
rho = 1.2;
Cd = vehicle.drag;
dims = vehicle.dims;
A = prod(dims)*0.0254^2;
D = rho*V.^2*Cd*A/2;
end