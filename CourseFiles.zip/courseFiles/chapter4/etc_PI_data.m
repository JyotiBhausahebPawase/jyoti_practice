% etc_PI_data.m
%
% Loads parameters for the etc_PI model

Kp = 0.3;
Ki = 2;
Ts = 0.01;