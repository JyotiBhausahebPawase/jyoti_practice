m = 1;       % Mass of ball [kg]
Cdrag = 1;   % Air resistance coefficient
g = 9.81;    % Acceleration due to gravity [m/s^2]
x0 = 0;      % Initial height [m]
xdot0 = 0;   % Initial velocity [m/s]