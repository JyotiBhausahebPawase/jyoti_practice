%Power diode parameters
diodeVolts = -5:5;
diodeCurrent = [-0.4,-0.2,-0.1,-0.05,-0.01,0.0,0.6,1.5,3.2,4.0,4.1];