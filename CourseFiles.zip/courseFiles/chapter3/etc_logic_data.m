% etc_logic_data.m
%
% Loads parameters for the etc_logic model

load PI_output;