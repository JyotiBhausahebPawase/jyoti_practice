% etc_controller_data.m
%
% Loads parameters for the etc_controller.mdl model

% Loads Ki, Kp, and Ts
etc_PI_data;
