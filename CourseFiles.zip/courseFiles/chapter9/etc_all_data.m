% etc_all_data.m
%
% Loads parameters for the etc_parent model, and similar

% Data for the controller
Kp = 0.3;
Ki = 2;
Ts = 0.01;

% Data for the plant
J = 2.4500e-004;
Ks = 0.2;
Kd = 0.03;
Cs = 3.0;
theta_eq = pi/6;

% Data for the sensor
degConv = 180/pi;