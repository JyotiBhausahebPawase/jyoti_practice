fs = 500; 
fc = 50; 
K = fs;  % 1 second of data
k = 0:(K-1);
x = cos(2*pi*fc/fs*k);

y = zeros(K,1);

p = 0.5;
y(1) = 0;  % Choose some initialization for y(1)
for n = 2:K
    y(n) = noise(n) + p*y(n-1);
end