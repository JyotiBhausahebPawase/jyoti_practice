clearvars;
% close all
h2r = 2*pi;
tStop = 1;
Fs = 48000;
dt=1/Fs;
t = (0:dt:tStop)';
%%
K = 0.05;
sig1 = sin(1*t*h2r);
sig2 = K*sin(2000*t*h2r);
noise = sig1 + sig2;
%%
b0 = 0.01;%04279673749836466;
a1 = 0.99;%9572032625016353;
%%
sim('iirFilter')
figure(1);plot(t,noise)
hold on; plot(tfil,yfil)
hold off
Y = filter(b0,[1 -a1], noise );
figure(2);plot(t,Y)
hold on; plot(tfil,yfil)
hold off
